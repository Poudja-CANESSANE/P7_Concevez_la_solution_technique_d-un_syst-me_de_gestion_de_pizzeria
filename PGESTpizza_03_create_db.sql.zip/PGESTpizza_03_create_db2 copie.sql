
CREATE TABLE public.pizza (
                name VARCHAR(100) NOT NULL,
                price NUMERIC(7,2) NOT NULL,
                CONSTRAINT pizza_pk PRIMARY KEY (name)
);


CREATE TABLE public.ingredient (
                name VARCHAR(100) NOT NULL,
                price NUMERIC(7,2) NOT NULL,
                CONSTRAINT ingredient_pk PRIMARY KEY (name)
);


CREATE TABLE public.recipe (
                ingredient_name VARCHAR(100) NOT NULL,
                pizza_name VARCHAR(100) NOT NULL,
                quantity INTEGER NOT NULL,
                CONSTRAINT recipe_pk PRIMARY KEY (ingredient_name, pizza_name)
);


CREATE SEQUENCE public.address_id_seq;

CREATE TABLE public.address (
                id INTEGER NOT NULL DEFAULT nextval('public.address_id_seq'),
                postal_code VARCHAR(100) NOT NULL,
                city VARCHAR(100) NOT NULL,
                street_number VARCHAR(100) NOT NULL,
                street_name VARCHAR(100) NOT NULL,
                CONSTRAINT address_pk PRIMARY KEY (id)
);


ALTER SEQUENCE public.address_id_seq OWNED BY public.address.id;

CREATE TABLE public.pizzeria (
                phone_number VARCHAR(100) NOT NULL,
                morning_opening_time TIME NOT NULL,
                morning_closing_time TIME NOT NULL,
                evening_opening_time TIME NOT NULL,
                evening_closing_time TIME NOT NULL,
                address_id INTEGER NOT NULL,
                CONSTRAINT pizzeria_pk PRIMARY KEY (phone_number)
);


CREATE TABLE public.menu (
                pizzeria_phone_number VARCHAR(100) NOT NULL,
                pizza_name VARCHAR(100) NOT NULL,
                CONSTRAINT menu_pk PRIMARY KEY (pizzeria_phone_number, pizza_name)
);


CREATE TABLE public.stock (
                ingredient_name VARCHAR(100) NOT NULL,
                pizzeria_phone_number VARCHAR(100) NOT NULL,
                quantity INTEGER NOT NULL,
                CONSTRAINT stock_pk PRIMARY KEY (ingredient_name, pizzeria_phone_number)
);


CREATE SEQUENCE public.employee_id_seq;

CREATE TABLE public.employee (
                id INTEGER NOT NULL DEFAULT nextval('public.employee_id_seq'),
                first_name VARCHAR(100) NOT NULL,
                last_name VARCHAR(100) NOT NULL,
                email VARCHAR(100) NOT NULL,
                password VARCHAR(100) NOT NULL,
                pizzeria_phone_number VARCHAR(100) NOT NULL,
                CONSTRAINT employee_pk PRIMARY KEY (id)
);


ALTER SEQUENCE public.employee_id_seq OWNED BY public.employee.id;

CREATE TABLE public.pizza_maker (
                employee_id INTEGER NOT NULL,
                CONSTRAINT pizza_maker_pk PRIMARY KEY (employee_id)
);


CREATE TABLE public.delivery_man (
                employee_id INTEGER NOT NULL,
                CONSTRAINT delivery_man_pk PRIMARY KEY (employee_id)
);


CREATE TABLE public.cashier (
                employee_id INTEGER NOT NULL,
                CONSTRAINT cashier_pk PRIMARY KEY (employee_id)
);


CREATE TABLE public.customer (
                phone_number VARCHAR(100) NOT NULL,
                first_name VARCHAR(100) NOT NULL,
                last_name VARCHAR(100) NOT NULL,
                email VARCHAR(100) NOT NULL,
                password VARCHAR(100) NOT NULL,
                address_id INTEGER NOT NULL,
                CONSTRAINT customer_pk PRIMARY KEY (phone_number)
);


CREATE SEQUENCE public.order_id_seq;

CREATE TABLE public.pizza_order (
                id INTEGER NOT NULL DEFAULT nextval('public.order_id_seq'),
                date TIMESTAMP NOT NULL,
                status VARCHAR(100) NOT NULL,
                payment_method VARCHAR(100) NOT NULL,
                is_already_pay_online BOOLEAN NOT NULL,
                customer_phone_number VARCHAR(100) NOT NULL,
                address_id INTEGER NOT NULL,
                pizzeria_phone_number VARCHAR(100) NOT NULL,
                CONSTRAINT pizza_order_pk PRIMARY KEY (id)
);


ALTER SEQUENCE public.order_id_seq OWNED BY public.pizza_order.id;

CREATE TABLE public.order_line (
                pizza_order_id INTEGER NOT NULL,
                pizza_name VARCHAR(100) NOT NULL,
                quantity INTEGER NOT NULL,
                price NUMERIC(7,2) NOT NULL,
                CONSTRAINT order_line_pk PRIMARY KEY (pizza_order_id, pizza_name)
);


ALTER TABLE public.recipe ADD CONSTRAINT pizza_recipe_fk
FOREIGN KEY (pizza_name)
REFERENCES public.pizza (name)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.order_line ADD CONSTRAINT pizza_order_line_fk
FOREIGN KEY (pizza_name)
REFERENCES public.pizza (name)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.menu ADD CONSTRAINT pizza_menu_fk
FOREIGN KEY (pizza_name)
REFERENCES public.pizza (name)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.stock ADD CONSTRAINT ingredient_stock_fk
FOREIGN KEY (ingredient_name)
REFERENCES public.ingredient (name)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.recipe ADD CONSTRAINT ingredient_recipe_fk
FOREIGN KEY (ingredient_name)
REFERENCES public.ingredient (name)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.customer ADD CONSTRAINT address_customer_fk
FOREIGN KEY (address_id)
REFERENCES public.address (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.pizza_order ADD CONSTRAINT address_order_fk
FOREIGN KEY (address_id)
REFERENCES public.address (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.pizzeria ADD CONSTRAINT address_pizzeria_fk
FOREIGN KEY (address_id)
REFERENCES public.address (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.employee ADD CONSTRAINT pizzeria_employee_fk
FOREIGN KEY (pizzeria_phone_number)
REFERENCES public.pizzeria (phone_number)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.pizza_order ADD CONSTRAINT pizzeria_order_fk
FOREIGN KEY (pizzeria_phone_number)
REFERENCES public.pizzeria (phone_number)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.stock ADD CONSTRAINT pizzeria_stock_fk
FOREIGN KEY (pizzeria_phone_number)
REFERENCES public.pizzeria (phone_number)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.menu ADD CONSTRAINT pizzeria_menu_fk
FOREIGN KEY (pizzeria_phone_number)
REFERENCES public.pizzeria (phone_number)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.cashier ADD CONSTRAINT employee_cashier_fk
FOREIGN KEY (employee_id)
REFERENCES public.employee (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.delivery_man ADD CONSTRAINT employee_delivery_man_fk
FOREIGN KEY (employee_id)
REFERENCES public.employee (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.pizza_maker ADD CONSTRAINT employee_pizza_maker_fk
FOREIGN KEY (employee_id)
REFERENCES public.employee (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.pizza_order ADD CONSTRAINT customer_order_fk
FOREIGN KEY (customer_phone_number)
REFERENCES public.customer (phone_number)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.order_line ADD CONSTRAINT order_order_line_fk
FOREIGN KEY (pizza_order_id)
REFERENCES public.pizza_order (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;
